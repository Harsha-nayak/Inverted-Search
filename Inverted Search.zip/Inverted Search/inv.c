#include "inv.h"

slist_t *head;                                                       //declare a link list node 

int main(int argc,char **argv)
{
    int op;
    hash_t arr[27];                                                  //declare hash table
    validate(argc,argv);                                             //function call to validate
    printf("\n");
    printf("Please choose any operation from below:\n");
    printf("1.Create database\n2.Display database\n3.Search database\n4.Update database\n5.Save database\n6.Exit\n");
    create_hash_table(arr,27);
    while(1)
    {
        scanf("%d", &op);
	switch(op)
	{
	    case 1: create_database(&head,arr);                      //to create database
		    break;
	    case 2: display_database(arr);                           //to display database
		    break;
            case 3: search_database(arr);                           //to search database
		    break;
	    case 4: update_database(arr);                           //to update database
		    break;
	    case 5: save_database(arr);                             //to save database
		    break;
	    case 6:
		    exit(0);
	    default:
		    printf("Please choose the appropriate operation!\n");
	}
    }
    return 0;
}
